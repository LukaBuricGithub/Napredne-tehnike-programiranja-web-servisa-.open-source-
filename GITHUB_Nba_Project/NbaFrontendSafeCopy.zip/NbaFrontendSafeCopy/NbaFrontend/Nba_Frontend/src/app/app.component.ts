import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NbaServiceService } from 'src/services/nba-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  title = 'Nba_Frontend';

  isAdmin!:any;

  isActive!:any;

  userID!:number;


  constructor(private router: Router,private service:NbaServiceService){ }

  ngOnInit(): void {
    
    this.isActive=this.service.returnLoggedValue();
    console.log(this.isActive);

    let pomValue=this.service.returnAdminValue();
    if(pomValue !=null && pomValue!=0)
    {
      this.isAdmin=pomValue;
    }
    console.log(this.isAdmin)

    let user=this.service.returnUserID();
    if(user !=null)
    {
      this.userID=user;
    }
    console.log(this.userID);


    // let isActive = localStorage.getItem('isActive');
    // if(isActive !== null)
    // {
    //   const active = JSON.parse(isActive);
    //   if(active=='true')
    //   {
    //     this.isActive=true;
    //   }
    //   else if (active=='false')
    //   {
    //     this.isActive=false;
    //   }
    // }
  }

  logout()
  {
    sessionStorage.clear();
  }

  goToCreateTeam(userID:number)
  {
    this.router.navigate(['/create-team'],{
      queryParams:{userID:userID}
    });
  }
  goToMyTeams(userID:number)
  {
    this.router.navigate(['/my-teams'],{
      queryParams:{userID:userID}
    });
  }

  

    //localStorage.setItem('userID',this.loggedUser.userID.toString());
    //      localStorage.setItem('isAdmin',isAdmin);

  //if(localStorage.getItem('token') )



    //const myObject = { key: 'value' };
//localStorage.setItem('myKey', JSON.stringify(myObject));

// Retrieving the object
// const storedData = localStorage.getItem('myKey');
// if (storedData !== null) {
//   const parsedData = JSON.parse(storedData);
//   console.log(parsedData);
//   }
}


