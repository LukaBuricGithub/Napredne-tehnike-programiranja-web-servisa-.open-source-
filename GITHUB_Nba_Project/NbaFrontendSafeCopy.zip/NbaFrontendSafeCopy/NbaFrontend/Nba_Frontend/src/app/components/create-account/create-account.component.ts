import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserForPost } from 'src/app/models/UserForPost';
import { NbaServiceService } from 'src/services/nba-service.service';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.scss']
})
export class CreateAccountComponent implements OnInit
{

  registrationForm!: FormGroup;

  constructor(private fb: FormBuilder,private service:NbaServiceService,private router:Router) { }

  ngOnInit(): void {
    this.registrationForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required],
    });
  }

  // private passwordMatchValidator(control: AbstractControl): { [key: string]: boolean } | null {
  //   const password = control.get('password')?.value;
  //   const confirmPassword = control.get('confirmPassword')?.value;
  //   return password === confirmPassword ? null : { 'passwordMismatch': true };
  // }

  //this.resetPasswordFormGroup = this.formbuilder.group({
    //currentPassword: ['', Validators.required],
    //newPassword: ['', Validators.required],
  //  confirmPassword: ['', Validators.required],
//}, { validator: this.checkPasswords });

//   checkPasswords(group: FormGroup) {
//     const pass = group.controls['password'].value;
//     const confirmPass = group.controls['confirmPassword'].value;
//     return pass === confirmPass ? null : { notSame: true };
// }


  // contactForm=new FormGroup({
  //   firstName:new FormControl("",[Validators.required]),
  //   lastName:new FormControl("",[Validators.required]),
  //   mail:new FormControl("",[Validators.email,Validators.required]),
  //   message:new FormControl("",[Validators.required])
  // });


  public submitData()
  {
    if(this.registrationForm.valid)
    {
      const newUser: UserForPost = {
        email: this.registrationForm.value.email,
        username: this.registrationForm.value.username,
        password: this.registrationForm.value.password,
        isActive: true,
        isAdmin: false,
      };

      console.log(newUser);
      this.service.postUser(newUser).subscribe((x)=>{});
      this.registrationForm.reset();
      this.router.navigate(['/index']);
    }
  }

  public enableSubmitBtn() : boolean
  {
    const password = this.registrationForm.get('password')?.value;
    const confirmPassword = this.registrationForm.get('confirmPassword')?.value;
    let match:boolean=false;

    if(password == confirmPassword)
    {
      match=true;
    }
    else
    {
      match=false;
    }
    return match;
  }
}
