import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatOption } from '@angular/material/core';
import {MatSelectModule} from '@angular/material/select';
import { ActivatedRoute, Router } from '@angular/router';
import { PlayerJSON,ListPlayerJSON } from 'src/app/models/PlayerJSON'; 
import { NbaServiceService } from 'src/services/nba-service.service';
import { User } from 'src/app/models/User';
import { TeamForPost } from 'src/app/models/TeamForPost';
import { PlayerForPost } from 'src/app/models/PlayerForPost'; 
import { Team } from 'src/app/models/Team';
import { Location } from '@angular/common';

@Component({
  selector: 'app-create-team',
  templateUrl: './create-team.component.html',
  styleUrls: ['./create-team.component.scss']
})

export class CreateTeamComponent implements OnInit{

  createTeamForm!:FormGroup;
  
  constructor(private service:NbaServiceService,private router:Router,private fb:FormBuilder,private _location: Location,private route: ActivatedRoute){}


  loggedUserId!:number;

  list1!:ListPlayerJSON;

  list2!:ListPlayerJSON;

  list3!:ListPlayerJSON;

  list4!:ListPlayerJSON;

  list5!:ListPlayerJSON;

  user!:User;

  listOfPlayers1:PlayerJSON[]=[];

  listOfPlayers2:PlayerJSON[]=[];

  listOfPlayers3:PlayerJSON[]=[];

  listOfPlayers4:PlayerJSON[]=[];

  listOfPlayers5:PlayerJSON[]=[];

  
  selectedPlayer1!:PlayerJSON;

  selectedPlayer2!:PlayerJSON;

  selectedPlayer3!:PlayerJSON;

  selectedPlayer4!:PlayerJSON;

  selectedPlayer5!:PlayerJSON;

  lastInsertedTeamId!:number;


  ngOnInit(): void {



    this.route.queryParams.subscribe(params => {
      let data1 = params['userID'];
      this.loggedUserId = Number(data1);
    });


    this.createTeamForm = this.fb.group({
      teamName:['', Validators.required] 
    });

    //this.service.getUserByID(1).subscribe( (x:User) =>{
      //this.user=x;
      //console.log(this.user);
    //});

    
    //this.service.getLastInsertedTeamId().subscribe((x:number)=>{
      //this.lastInsertedTeamId=x;
      //console.log(this.lastInsertedTeamId);
    //});
    
    // this.service.getPlayersFromJSON(filtedData).subscribe((x:ListPlayerJSON)=>{
    //   listJSON=x;
    //   this.listOfPlayers1=x.data;
    // }); 

    this.service.getPlayersFromJSON('abe').subscribe((x:ListPlayerJSON)=>{
       this.list1=x;
       console.log(this.list1);
       this.listOfPlayers1=this.list1.data;
       console.log(this.listOfPlayers1);
     });

     this.service.getPlayersFromJSON('abe').subscribe((x:ListPlayerJSON)=>{
      this.list2=x;
      console.log(this.list2);
      this.listOfPlayers2=this.list2.data;
      console.log(this.listOfPlayers2);
    });

    this.service.getPlayersFromJSON('abe').subscribe((x:ListPlayerJSON)=>{
      this.list3=x;
      console.log(this.list3);
      this.listOfPlayers3=this.list3.data;
      console.log(this.listOfPlayers3);
    });

    this.service.getPlayersFromJSON('abe').subscribe((x:ListPlayerJSON)=>{
      this.list4=x;
      console.log(this.list4);
      this.listOfPlayers4=this.list4.data;
      console.log(this.listOfPlayers4);
    });

    this.service.getPlayersFromJSON('abe').subscribe((x:ListPlayerJSON)=>{
      this.list5=x;
      console.log(this.list5);
      this.listOfPlayers5=this.list5.data;
      console.log(this.listOfPlayers5);
    });

    //localStorage.setItem('user',JSON.stringify(this.user))
    //JSON.parse(localStorage.getItem('user') as User);
  }

selectedPlayers1=this.listOfPlayers1;

selectedPlayers2=this.listOfPlayers2;

selectedPlayers3=this.listOfPlayers3;

selectedPlayers4=this.listOfPlayers4;

selectedPlayers5=this.listOfPlayers5;

//onKey(value:string) { 
//this.selectedStates = this.search(value);
//}

onKey1(event: Event) {
  if (event instanceof KeyboardEvent) {
    const value = (event.target as HTMLInputElement).value;
    
    let filterDataConvert = value.toString();
    let filtedData=filterDataConvert.toLowerCase();
    let listJSON!:ListPlayerJSON;
    this.service.getPlayersFromJSON(filtedData).subscribe((x:ListPlayerJSON)=>{
      listJSON=x;
      this.listOfPlayers1=x.data;
    }); 
    //this.selectedPlayers=listJSON.data;
    //this.selectedPlayers = this.search(value);
  }
}
onKey2(event: Event) {
  if (event instanceof KeyboardEvent) {
    const value = (event.target as HTMLInputElement).value;
    
    let filterDataConvert = value.toString();
    let filtedData=filterDataConvert.toLowerCase();
    let listJSON!:ListPlayerJSON;
    this.service.getPlayersFromJSON(filtedData).subscribe((x:ListPlayerJSON)=>{
      listJSON=x;
      this.listOfPlayers2=x.data;
    }); 
    //this.selectedPlayers=listJSON.data;
    //this.selectedPlayers = this.search(value);
  }
}
onKey3(event: Event) {
  if (event instanceof KeyboardEvent) {
    const value = (event.target as HTMLInputElement).value;
    
    let filterDataConvert = value.toString();
    let filtedData=filterDataConvert.toLowerCase();
    let listJSON!:ListPlayerJSON;
    this.service.getPlayersFromJSON(filtedData).subscribe((x:ListPlayerJSON)=>{
      listJSON=x;
      this.listOfPlayers3=x.data;
    }); 
    //this.selectedPlayers=listJSON.data;
    //this.selectedPlayers = this.search(value);
  }
}
onKey4(event: Event) {
  if (event instanceof KeyboardEvent) {
    const value = (event.target as HTMLInputElement).value;
    
    let filterDataConvert = value.toString();
    let filtedData=filterDataConvert.toLowerCase();
    let listJSON!:ListPlayerJSON;
    this.service.getPlayersFromJSON(filtedData).subscribe((x:ListPlayerJSON)=>{
      listJSON=x;
      this.listOfPlayers4=x.data;
    }); 
    //this.selectedPlayers=listJSON.data;
    //this.selectedPlayers = this.search(value);
  }
}
onKey5(event: Event) {
  if (event instanceof KeyboardEvent) {
    const value = (event.target as HTMLInputElement).value;
    
    let filterDataConvert = value.toString();
    let filtedData=filterDataConvert.toLowerCase();
    let listJSON!:ListPlayerJSON;
    this.service.getPlayersFromJSON(filtedData).subscribe((x:ListPlayerJSON)=>{
      listJSON=x;
      this.listOfPlayers5=x.data;
    }); 
    //this.selectedPlayers=listJSON.data;
    //this.selectedPlayers = this.search(value);
  }
}

public submitData()
{
  // if(this.registrationForm.valid)
  // {
  //   const newUser: UserForPost = {
  //     email: this.registrationForm.value.email,
  //     username: this.registrationForm.value.username,
  //     password: this.registrationForm.value.password,
  //     isActive: true,
  //     isAdmin: false,
  //   };

  //   console.log(newUser);
  //   this.service.postUser(newUser).subscribe((x)=>{});
  //   this.registrationForm.reset();
  //   this.router.navigate(['/index']);
  // }

  if(this.createTeamForm.valid && this.selectedPlayer1 !=null && this.selectedPlayer2 !=null && this.selectedPlayer3 !=null 
    && this.selectedPlayer4 !=null && this.selectedPlayer5 !=null)
    {
      const newTeam: TeamForPost= {
        teamName:this.createTeamForm.value.teamName,
        userID:this.loggedUserId,
      };

      this.service.postTeam(newTeam).subscribe((response:any) => {
        
        const newTeamId = response.teamID;

        const newPlayer1: PlayerForPost = {
          playerJSONID: this.selectedPlayer1.id,
          firstName: this.selectedPlayer1.first_name,
          lastName: this.selectedPlayer1.last_name,
          position: this.selectedPlayer1.position,
          teamID: newTeamId, 
        };
  
        const newPlayer2: PlayerForPost = {
          playerJSONID: this.selectedPlayer2.id,
          firstName: this.selectedPlayer2.first_name,
          lastName: this.selectedPlayer2.last_name,
          position: this.selectedPlayer2.position,
          teamID: newTeamId,
        };
  
        const newPlayer3: PlayerForPost = {
          playerJSONID: this.selectedPlayer3.id,
          firstName: this.selectedPlayer3.first_name,
          lastName: this.selectedPlayer3.last_name,
          position: this.selectedPlayer3.position,
          teamID: newTeamId,
        };
  
        const newPlayer4: PlayerForPost = {
          playerJSONID: this.selectedPlayer4.id,
          firstName: this.selectedPlayer4.first_name,
          lastName: this.selectedPlayer4.last_name,
          position: this.selectedPlayer4.position,
          teamID: newTeamId,
        };
  
        const newPlayer5: PlayerForPost = {
          playerJSONID: this.selectedPlayer5.id,
          firstName: this.selectedPlayer5.first_name,
          lastName: this.selectedPlayer5.last_name,
          position: this.selectedPlayer5.position,
          teamID: newTeamId,
        };
        
        this.service.postPlayer(newPlayer1).subscribe((x)=>{});
        this.service.postPlayer(newPlayer2).subscribe((x)=>{});
        this.service.postPlayer(newPlayer3).subscribe((x)=>{});
        this.service.postPlayer(newPlayer4).subscribe((x)=>{});
        this.service.postPlayer(newPlayer5).subscribe((x)=>{});

        console.log("Data that I need:");
        console.log(newTeam);
        console.log(newPlayer1);
        console.log(newPlayer2);
        console.log(newPlayer3);
        console.log(newPlayer4);
        console.log(newPlayer5); 
      });


      //this.service.getLastInsertedTeamId().subscribe((x:number)=>{
        //this.lastInsertedTeamId=x;
        //console.log(this.lastInsertedTeamId);
      //});
      
      // const newPlayer1: PlayerForPost= {
      //   playerJSONID:this.selectedPlayer1.id,
      //   firstName:this.selectedPlayer1.first_name,
      //   lastName:this.selectedPlayer1.last_name,
      //   position:this.selectedPlayer1.position,
      //   teamID:this.lastInsertedTeamId
      // };

      // const newPlayer2: PlayerForPost= {
      //   playerJSONID:this.selectedPlayer2.id,
      //   firstName:this.selectedPlayer2.first_name,
      //   lastName:this.selectedPlayer2.last_name,
      //   position:this.selectedPlayer2.position,
      //   teamID:this.lastInsertedTeamId
      // };

      // const newPlayer3: PlayerForPost= {
      //   playerJSONID:this.selectedPlayer3.id,
      //   firstName:this.selectedPlayer3.first_name,
      //   lastName:this.selectedPlayer3.last_name,
      //   position:this.selectedPlayer3.position,
      //   teamID:this.lastInsertedTeamId
      // };

      // const newPlayer4: PlayerForPost= {
      //   playerJSONID:this.selectedPlayer4.id,
      //   firstName:this.selectedPlayer4.first_name,
      //   lastName:this.selectedPlayer4.last_name,
      //   position:this.selectedPlayer4.position,
      //   teamID:this.lastInsertedTeamId
      // };

      // const newPlayer5: PlayerForPost= {
      //   playerJSONID:this.selectedPlayer5.id,
      //   firstName:this.selectedPlayer5.first_name,
      //   lastName:this.selectedPlayer5.last_name,
      //   position:this.selectedPlayer5.position,
      //   teamID:this.lastInsertedTeamId
      // };

      // this.service.postPlayer(newPlayer1).subscribe((x)=>{});;
      // this.service.postPlayer(newPlayer2).subscribe((x)=>{});;
      // this.service.postPlayer(newPlayer3).subscribe((x)=>{});;
      // this.service.postPlayer(newPlayer4).subscribe((x)=>{});;
      // this.service.postPlayer(newPlayer5).subscribe((x)=>{});;

    // console.log("Data that I need:");
    // console.log(newTeam);
    // console.log(newPlayer1);
    // console.log(newPlayer2);
    // console.log(newPlayer3);
    // console.log(newPlayer4);
    // console.log(newPlayer5);  
  }


}

public enableSubmitBtn() : boolean
{
  // const password = this.registrationForm.get('password')?.value;
  // const confirmPassword = this.registrationForm.get('confirmPassword')?.value;
  // let match:boolean=false;

  // if(password == confirmPassword)
  // {
  //   match=true;
  // }
  // else
  // {
  //   match=false;
  // }
  // return match;
  return true;
}

// search(value: string):void { 
//   let filter = value.toLowerCase();
//   let filterData:PlayerJSON[]=[];

//   this.service.getPlayersFromJSON(filter).subscribe((x:ListPlayerJSON)=>{
//     //this.list=x;
//     //console.log(this.list);
//     filterData=x.data;
//     console.log(filterData);
//     return filterData;
//   });
// }
}
