import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/models/User';
import { NbaServiceService } from 'src/services/nba-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  
  loginForm!:FormGroup;

  loggedUser!:User;

  constructor(private fb: FormBuilder,private service:NbaServiceService,private router:Router) { }

  
  ngOnInit(): void {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
    });

    /*
    this.service.getUserByID(1).subscribe((x:User)=>{
      this.userGet=x;
      console.log(this.userGet);

      this.editForm = this.fb.group({
        username: [this.userGet.username, Validators.required]
      });

      this.editForm.value.username=this.userGet.username;
    });*/
  }

  public submitData()
  {
    if(this.loginForm.valid)
    {

      this.service.loginUser(this.loginForm.value.email,this.loginForm.value.password).subscribe((x:User) =>{
        this.loggedUser=x;
        if(this.loggedUser==null)
        {
          console.log("Neuspjeh");
        }
        else
        {
          const active="1";
          console.log("Tocan login");
          sessionStorage.setItem('isActive',active);

          let admin:string;
          if(this.loggedUser.isAdmin)
          {
            admin="1";
          }
          else
          {
            admin="0"
          }
          sessionStorage.setItem('isAdmin',admin);

          let userID:string;
          userID=this.loggedUser.userID.toString();
          sessionStorage.setItem('userId',userID);

          
        
          // let isAdmin:string="";
          // let isActive:string="";
          // if(this.loggedUser.isAdmin)
          // {
          //   isAdmin="true";
          // }
          // else if(!this.loggedUser.isAdmin){
          //   isAdmin="false";
          // }

          // if(this.loggedUser.isActive)
          // {
          //   isActive="true"
          // }
          // else if(!this.loggedUser.isActive)
          // {
          //   isActive="false";
          // }

          // localStorage.setItem('userID',this.loggedUser.userID.toString());
          // localStorage.setItem('isAdmin',isAdmin);
          // localStorage.setItem('isActive',isActive);
          
          
          // console.log(localStorage.getItem('userID'));
          // console.log(localStorage.getItem('isAdmin'));
          // console.log(localStorage.getItem('isActive'));

          // console.log(this.loggedUser);
        }
      })
      //const updatedUser: User = {
        //userID:this.userGet.userID,
        //email:this.userGet.email,
        //username:this.editForm.value.username,
        //password:this.userGet.password,
        //isActive:this.userGet.isActive,
        //isAdmin:this.userGet.isAdmin,
      //};

      //console.log(updatedUser);
      //this.service.updateUser(updatedUser).subscribe((x)=>{});
      //this.service.postUser(newUser).subscribe((x)=>{});
      //this.editForm.reset();
      //this.router.navigate(['/index']);
    }
  }

  public enableSubmitBtn() : boolean
  {
    let enable:boolean=false;
    if(this.loginForm.valid)
    {
      enable=true;
    }
    else
    {
      enable:false;
    }
    return enable;
  }

}
