import { Component } from '@angular/core';

@Component({
  selector: 'app-show-all-teams',
  templateUrl: './show-all-teams.component.html',
  styleUrls: ['./show-all-teams.component.scss']
})
export class ShowAllTeamsComponent {

}
