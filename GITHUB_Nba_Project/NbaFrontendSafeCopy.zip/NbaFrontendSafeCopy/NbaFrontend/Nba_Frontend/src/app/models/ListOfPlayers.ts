import { Player } from "./Player";

//export interface ListOfListsOfPlayes
//{
    //data:Array<ListOfPlayers>;
//}

export interface ListOfPlayers
{
    data:Array<Player[]>;
}