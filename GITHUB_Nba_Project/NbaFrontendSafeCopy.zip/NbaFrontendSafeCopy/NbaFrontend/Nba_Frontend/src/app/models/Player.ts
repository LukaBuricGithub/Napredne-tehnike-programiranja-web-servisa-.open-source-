export interface Player
{
    playerID: number;
    playerJSONID: number;
    firstName: string;
    lastName: string;
    position:string;
    teamID: number;
}