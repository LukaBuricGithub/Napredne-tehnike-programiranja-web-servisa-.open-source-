export interface PlayerForPost
{
    playerJSONID:number;
    firstName:string;
    lastName:string;
    position:string;
    teamID:number;
}