export interface Team
{
    teamID:number;
    teamName: string;
    userID: number;
}