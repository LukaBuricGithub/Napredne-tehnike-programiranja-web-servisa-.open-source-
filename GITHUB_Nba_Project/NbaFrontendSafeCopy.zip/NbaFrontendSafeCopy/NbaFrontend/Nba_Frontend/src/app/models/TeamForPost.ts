export interface TeamForPost
{
    teamName: string;
    userID: number;
}
