export interface User
{
    userID:number;
    email:string;
    username:string;
    password:string;
    isActive:boolean;
    isAdmin:boolean;
}