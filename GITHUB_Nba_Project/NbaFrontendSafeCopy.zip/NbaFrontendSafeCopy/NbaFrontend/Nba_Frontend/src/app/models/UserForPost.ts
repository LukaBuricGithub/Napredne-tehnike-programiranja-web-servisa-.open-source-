export interface UserForPost
{
    email:string;
    username:string;
    password:string;
    isActive:boolean;
    isAdmin:boolean;
}
